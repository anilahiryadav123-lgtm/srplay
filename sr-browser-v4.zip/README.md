# S.R Browser 1.2 (Android) - Made in India
WebView browser with UC style screens: welcome, home, 5-icon menu, tab switcher, history (Video/Website),
downloader, notes, settings list, theme zone, ad block, Hindi/English.
Official logos (optional): app/src/main/assets/engines/google.png and app/src/main/assets/icons/yt.png etc.
