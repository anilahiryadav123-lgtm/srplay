package com.sr.browser;

/** Colour palette: light (default, like UC) or night. Accent red comes from the SR logo. */
final class Pal {
    static final int RED = 0xFFE5121B;

    final boolean night;
    final int bg, bar, surface, surface2, line, fg, muted, accent, onAccent, sheet, icon;

    Pal(boolean night) {
        this.night = night;
        accent = RED;
        onAccent = 0xFFFFFFFF;
        if (night) {
            bg = 0xFF0F1115;
            bar = 0xFF171A20;
            surface = 0xFF1B1F27;
            surface2 = 0xFF252A34;
            line = 0xFF2E3440;
            fg = 0xFFF2F4F8;
            muted = 0xFF8E96A6;
            sheet = 0xFF1A1D24;
            icon = 0xFFD3D8E2;
        } else {
            bg = 0xFFF7F9FC;
            bar = 0xFFFFFFFF;
            surface = 0xFFFFFFFF;
            surface2 = 0xFFF0F2F6;
            line = 0xFFE4E7EE;
            fg = 0xFF1A1D23;
            muted = 0xFF8A90A0;
            sheet = 0xFFF6F7FA;
            icon = 0xFF3B4150;
        }
    }
}
