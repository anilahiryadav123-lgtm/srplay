package com.sr.browser;

import java.util.HashMap;
import java.util.Map;

/** English to Hindi labels for the main screens. Anything not listed stays in English. */
final class Strings {
    private static final Map<String, String> HI = new HashMap<>();

    static {
        HI.put("Bookmarks", "बुकमार्क");
        HI.put("Bookmark", "बुकमार्क");
        HI.put("History", "इतिहास");
        HI.put("Downloads", "डाउनलोड");
        HI.put("Downloader", "डाउनलोडर");
        HI.put("Themes", "थीम");
        HI.put("More Tools", "और टूल्स");
        HI.put("Add to Bookmarks", "बुकमार्क जोड़ें");
        HI.put("Night", "रात मोड");
        HI.put("Refresh", "रिफ्रेश");
        HI.put("Feedback", "फीडबैक");
        HI.put("Share", "शेयर");
        HI.put("Settings", "सेटिंग्स");
        HI.put("Notes", "नोट्स");
        HI.put("Search or Enter URL", "खोजें या URL डालें");
        HI.put("Enter URL", "URL डालें");
        HI.put("Search", "खोजें");
        HI.put("Made in India", "भारत में निर्मित");
        HI.put("Agree and Enter", "सहमत हैं, आगे बढ़ें");
        HI.put("SR Center", "SR सेंटर");
        HI.put("AD Setting", "विज्ञापन सेटिंग");
        HI.put("Customized Banner", "कस्टम बैनर");
        HI.put("Set as Default Browser", "डिफ़ॉल्ट ब्राउज़र बनाएं");
        HI.put("Browsing Settings", "ब्राउज़िंग सेटिंग्स");
        HI.put("Download Settings", "डाउनलोड सेटिंग्स");
        HI.put("Notification Settings", "नोटिफिकेशन सेटिंग्स");
        HI.put("Search Settings", "सर्च सेटिंग्स");
        HI.put("Social Media Downloader Settings", "सोशल मीडिया डाउनलोडर");
        HI.put("Data Saver", "डेटा सेवर");
        HI.put("Language", "भाषा");
        HI.put("Clear Records", "रिकॉर्ड साफ़ करें");
        HI.put("Video", "वीडियो");
        HI.put("Website", "वेबसाइट");
        HI.put("Edit", "एडिट");
        HI.put("Exit", "बाहर निकलें");
        HI.put("Tabs", "टैब");
        HI.put("Theme Zone", "थीम ज़ोन");
        HI.put("Local Photos", "फ़ोन की फ़ोटो");
        HI.put("Web", "वेब");
        HI.put("Videos", "वीडियो");
        HI.put("Images", "फ़ोटो");
        HI.put("Incognito mode on", "इन्कॉग्निटो मोड चालू");
        HI.put("Fast. Simple. Made in India.", "तेज़। आसान। भारत में बना।");
    }

    private Strings() {
    }

    static String tr(String lang, String s) {
        if ("hi".equals(lang)) {
            String v = HI.get(s);
            if (v != null) return v;
        }
        return s;
    }
}
